package com.cts.inventory.entity;



import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name="stock")
public class StockDetails {
	
	@Id
	@Column(name="product_Id")
	private int  productID;
	@Column(name="product_Name")
    private String productName;
	@Column(name="quantity")
    private int quantity;
	@Column(name="manufacturedDate")
    private String manufacturedDate;
	@Column(name="price")
    private int price;


    // Constructor
    public StockDetails() {
    	
    }
    public StockDetails(int  productID, String productName,  int quantity, String manufacturedDate, int price) {
    	super();
        this. productID=  productID;
        this.productName = productName;
        
        this.quantity = quantity;
        this.manufacturedDate =manufacturedDate;
        this.price = price;
    }

	public int getproductID() {
		return productID;
	}

	public void setproductID(int  productID) {
		this. productID =  productID;
	}

	public String getproductName() {
		return productName;
	}

	public void setproductName(String productName) {
		this.productName = productName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getmanufacturedDate() {
		return manufacturedDate;
	}

	public void setmanufacturedDate(String manufacturedDate) {
		this.manufacturedDate = manufacturedDate;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

}

	


