package com.cts.inventory.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.inventory.entity.SupplierDetails;

public interface Supplierrepository extends JpaRepository<SupplierDetails,Integer>{

}



