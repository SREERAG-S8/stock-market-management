package com.cts.inventory.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.inventory.entity.StockDetails;

public interface Stockrepository extends JpaRepository<StockDetails,Integer>{

	

	

}
