package com.cts.inventory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StocktrackManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(StocktrackManagementSystemApplication.class, args);
	}

}
