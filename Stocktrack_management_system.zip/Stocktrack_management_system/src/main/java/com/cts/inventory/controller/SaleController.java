package com.cts.inventory.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.inventory.entity.SalesDetails;
import com.cts.inventory.service.saleservice;

@RestController
@RequestMapping("/sales")
public class SaleController {
	
	@Autowired
	public saleservice saleservices;
	
	@GetMapping("/getAllsale")
	public List<SalesDetails> getAllSales(){
		
		return saleservices.getAllSales();
	}
	
	@GetMapping("/getById/{saleID}")
	public SalesDetails getSalesDetailsById(@PathVariable int saleID ) {
		return saleservices.getSalesDetailsById(saleID);
	}
	
	
	@RequestMapping(method=RequestMethod.POST,value="/salecreate")
	public void addSale(@RequestBody SalesDetails salesdetails)
	{
		saleservices.addSale(salesdetails);
	}
	
	
	@RequestMapping(method=RequestMethod.PUT,value ="/updatesale")
	public void updateSale(@RequestBody SalesDetails salesdetails)
	{
		saleservices.updateSale(salesdetails);
	}
	

	@DeleteMapping("/deletesale/{saleID}")
	public String deleteSale(@PathVariable int saleID)
	{
		saleservices.deleteSale(saleID);
		return "deleted the required column "+saleID;
	}
	

}
