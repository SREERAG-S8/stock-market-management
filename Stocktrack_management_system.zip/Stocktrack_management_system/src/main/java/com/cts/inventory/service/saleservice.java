package com.cts.inventory.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.inventory.entity.SalesDetails;
import com.cts.inventory.repository.Salesrepository;

@Service
public class saleservice {
	
	@Autowired
	public Salesrepository salesrepo;

	public List<SalesDetails> getAllSales(){
		
		   List<SalesDetails> salesdetails= new ArrayList<>();
		   salesrepo.findAll().forEach(salesdetails::add);
		   return salesdetails;
		}
	public void addSale(SalesDetails salesdetails) {
		salesrepo.save(salesdetails);
	}
	
	public SalesDetails getSalesDetailsById(int saleID) {
		
		return salesrepo.findById(saleID).orElse(null);
	}
	
	public  void updateSale(SalesDetails salesdetails)
	{
		SalesDetails updatesale=salesrepo.findById(salesdetails.getSaleID()).orElse(null);
		if(updatesale!=null) {
			updatesale.setCustomerName(salesdetails.getCustomerName());
			updatesale.setCustomerContact(salesdetails.getCustomerContact());
			updatesale.setPrice(salesdetails.getPrice());
			updatesale.setQuantity(salesdetails.getQuantity());
			updatesale.setTotalAmount(salesdetails.getPrice()*salesdetails.getQuantity());
			
		}
		salesrepo.save(updatesale);
	}
	
	public void deleteSale(int saleID) {
		
		salesrepo.deleteById(saleID);
	}
	
	

}
		

	


