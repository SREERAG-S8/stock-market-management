package com.cts.inventory.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.inventory.entity.StockDetails;
import com.cts.inventory.repository.Stockrepository;
@Service
public class stockservice {
	
	@Autowired
	public Stockrepository  stockrepo;
	
	public List<StockDetails> getAllStocks(){
		
	   List<StockDetails>stockdetails=new ArrayList<>();
	
	  stockrepo.findAll().forEach(stockdetails::add);
	  
	
	   return stockdetails;
	   
	}
	
	public void addStock(StockDetails stockdetails) {
		 stockrepo.save(stockdetails);
	}
	
	public StockDetails getStockDetailstById(int drugID) {
		
		return stockrepo.findById(drugID).orElse(null);
	}
	
	public  void updateStock(StockDetails stockdetails)
	{
		StockDetails updatestock=stockrepo.findById(stockdetails.getproductID()).orElse(null);
		if(updatestock!=null) {
			updatestock.setproductName(stockdetails.getproductName());
			updatestock.setQuantity(stockdetails.getQuantity());
			updatestock.setmanufacturedDate(stockdetails.getmanufacturedDate());
			updatestock.setPrice(stockdetails.getPrice());
			
		}
		stockrepo.save(updatestock);
	}
	
	public void deleteStock(int productID) {
		
		stockrepo.deleteById(productID);
	}
	 
	

}
