package com.cts.inventory.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.inventory.entity.SupplierDetails;
import com.cts.inventory.repository.Supplierrepository;

@Service
public class SupplierService {
	@Autowired
	public Supplierrepository supplierrepo ;
	
	public List<SupplierDetails> getAllSupplier(){
		
	   List<SupplierDetails>supplierdetails=new ArrayList<>();
	   supplierrepo.findAll().forEach(supplierdetails::add);
	   return supplierdetails;
	}
	
	public void addSupplierDetails(SupplierDetails supplierdetails) {
		supplierrepo.save(supplierdetails);
	}
	
	public SupplierDetails getSupplierDetailstById(int supplierID) {
		
		return supplierrepo.findById(supplierID).orElse(null);
	}
	
	
	public  void updateSupplierDetails(SupplierDetails supplierdetails)
	{
		SupplierDetails updatesupplier=supplierrepo.findById(supplierdetails.getSupplierID()).orElse(null);
		if(updatesupplier!=null) {
			updatesupplier.setSupplierName(supplierdetails.getSupplierName());
			
			updatesupplier.setSupplierContact(supplierdetails.getSupplierContact());
			}
		supplierrepo.save(updatesupplier);
	}
	
	public void deleteSupplierId(int supplierID) {
		
		supplierrepo.deleteById(supplierID);
	}
	 

}
