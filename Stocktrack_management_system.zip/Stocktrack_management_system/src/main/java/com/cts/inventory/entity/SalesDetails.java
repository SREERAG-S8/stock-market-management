package com.cts.inventory.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;

import jakarta.persistence.Table;

@Entity
@Table(name="sales")
public class SalesDetails {
	@Id
	private int saleID;
    private String customerName;
    private String customerContact;
    
    
    @JoinColumn(name = "product_id",referencedColumnName=" productID") 
    private  int productID;  
        
    private int price;
    private int quantity;
    
    private int totalAmount;
	
    
    public SalesDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    // Constructor
    public SalesDetails(int saleID, String customerName, String customerContact ,int productID, int price, int quantity, int totalAmount) {
        this.saleID = saleID;
        this.customerName = customerName;
        this.customerContact = customerContact;
        this. productID = productID;
        this.price = price;
        this.quantity = quantity;
        this.totalAmount = totalAmount;
    }

    public int getSaleID() {
		return saleID;
	}

	public void setSaleID(int saleID) {
		this.saleID = saleID;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerContact() {
		return customerContact;
	}

	public void setCustomerContact(String customerContact) {
		this.customerContact = customerContact;
	}
	
	public int getproductID() {
		return  productID;
	}

	public void setproductID(int  productID) {
		this. productID =  productID;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(int totalAmount) {
		this.totalAmount = totalAmount;
	}
}






