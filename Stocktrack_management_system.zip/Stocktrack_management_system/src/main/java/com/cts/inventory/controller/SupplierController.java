package com.cts.inventory.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.inventory.entity.SupplierDetails;
import com.cts.inventory.service.SupplierService;


@RestController
@RequestMapping("/supplier")
public class SupplierController {
	
	@Autowired
	private SupplierService supplierservice;
	
	@GetMapping("/getAllsupplier")
	public List<SupplierDetails> getAllSupplier(){
		
		return supplierservice.getAllSupplier();
	}
	
	@GetMapping("/getById/{supplierID}")
	public SupplierDetails getSupplierDetailstById(@PathVariable int supplierID) {
		return  supplierservice.getSupplierDetailstById(supplierID);
	}
	
	
	@RequestMapping(method=RequestMethod.POST,value="/suppliercreate")
	public void addSupplierDetails(@RequestBody SupplierDetails supplierdetails)
	{
		supplierservice.addSupplierDetails( supplierdetails);
	}
	
	
	@RequestMapping(method=RequestMethod.PUT,value ="/updatesupplier")
	public void updateSupplierDetails(@RequestBody SupplierDetails supplierdetails )
	{
		supplierservice.updateSupplierDetails(supplierdetails);
	}
	

	@DeleteMapping("/deletesupplier/{supplierID}")
	public String deleteSupplierId(@PathVariable int supplierID)
	{
		supplierservice.deleteSupplierId(supplierID);
		return "deleted the required column "+supplierID;
	}
	
	

}
