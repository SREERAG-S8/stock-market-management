package com.cts.inventory.entity; 

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;

import jakarta.persistence.Table;

@Entity
@Table(name="supplier")
public class SupplierDetails {
	@Id
	private int supplierID;
    private String supplierName;
    
    @JoinColumn(name = "product_id",referencedColumnName="productID") 
    private int productID;
    private String supplierContact;
    
    public SupplierDetails() {
    	super();
    }

    // Constructor
    public SupplierDetails(int supplierID, String supplierName, int  productID ,String supplierContact) {
        this.supplierID = supplierID;
        this.supplierName = supplierName;
        this. productID =  productID;
        this.supplierContact = supplierContact;
    }
    
    // Getters and setters	

	public int getSupplierID() {
		return supplierID;
	}

	public void setSupplierID(int supplierID) {
		this.supplierID = supplierID;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
    
	public String getSupplierContact() {
		return supplierContact;
	}
	
	public void setSupplierContact(String supplierContact) {
		this.supplierContact = supplierContact;
	}

	public int getproductID() {
		return  productID;
	}

	public void setproductID(int  productID) {
		this. productID =  productID;
	}
	


}



